Pozdrav :)
U datoteci Rjesenja nalaze se moja rje�enja seminara. Sva rje�enja rade, me�utim, u prvom seminaru sje�am se da je ne�to
rje�eno ne ba� kako treba (ali radi). Mislim da se radi o tome da sam stavio neki timer vi�ka, a da se to trebalo
srediti na neki drugi na�in. Ostali seminari bi trebali biti to�ni. 

Sretno :)